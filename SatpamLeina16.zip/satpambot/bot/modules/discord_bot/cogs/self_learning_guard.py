from __future__ import annotations

import asyncio
from typing import List, Optional, Set

import discord
from discord.ext import commands

from satpambot.ml.feature_extractor import dhash64, extract_tokens, sha1k
from satpambot.ml.online_nb import OnlineNB
from satpambot.ml.phash_reconcile import (
    collect_image_hashes_from_thread,
    collect_phash_from_log,
    split_false_positives,
)
from satpambot.ml.state_store_discord import (
    MAX_ATTACH_PER_MSG,
    MAX_MESSAGES_SCAN,
    MLState,
)

AUTO_BOOT = True



PHASH_HAMMING_THR = 6











class SelfLearningGuard(commands.Cog):



    def __init__(self, bot: commands.Bot):



        self.bot = bot



        self.state = MLState(bot)



        self._ready = asyncio.Event()







    @commands.Cog.listener()



    async def on_ready(self):



        if self._ready.is_set():



            return



        await self.state.load_latest()



        if AUTO_BOOT:



            await self._auto_bootstrap()



        self._ready.set()







    async def _scan_thread_tokens(self, th: discord.Thread, label: str) -> int:



        if self.state.model is None:



            self.state.model = OnlineNB()



        n = 0



        async for msg in th.history(limit=MAX_MESSAGES_SCAN, oldest_first=True):



            tokens = extract_tokens(msg.content or "", None)



            if msg.attachments:



                tokens.append("has_image")



            if tokens:



                self.state.model.learn(tokens, label)



                n += 1



        return n







    async def _scan_thread_wl(self, th: discord.Thread) -> int:



        cnt = 0



        async for msg in th.history(limit=MAX_MESSAGES_SCAN, oldest_first=True):



            for a in msg.attachments[:MAX_ATTACH_PER_MSG]:



                if a.content_type and a.content_type.startswith("image/"):



                    try:



                        b = await a.read()



                    except Exception:



                        continue



                    h1 = dhash64(b)



                    h2 = sha1k(b)



                    if h1 and h1 not in self.state.combined.whitelist["dhash64"]:



                        self.state.combined.whitelist["dhash64"].append(h1)



                    if h2 and h2 not in self.state.combined.whitelist["sha1k"]:



                        self.state.combined.whitelist["sha1k"].append(h2)



                    cnt += 1



        return cnt







    async def _phash_reconcile(self, log_ch: Optional[discord.TextChannel], phish_threads: List[discord.Thread]) -> int:



        if log_ch is None or not phish_threads:



            return 0



        log_hashes = await collect_phash_from_log(log_ch, limit_msgs=400)



        if not log_hashes:



            return 0



        phish_hashes: Set[str] = set()



        for th in phish_threads[:2]:



            phish_hashes |= await collect_image_hashes_from_thread(th, limit_msgs=250)



        tps, fps = split_false_positives(log_hashes, phish_hashes, ham_thr=PHASH_HAMMING_THR)



        wl = self.state.combined.whitelist["dhash64"]



        changed = 0



        for h in fps:



            if h not in wl:



                wl.append(h)



                changed += 1



        return changed







    async def _auto_bootstrap(self):



        parent = self.state.find_log_channel()



        if parent:



            self.state.parent_channel_id = parent.id







        phish_threads, wl_threads, banlog_threads, blacklist_threads, state_threads = self.state.classify_threads()







        for th in set(self.state.all_active_threads()):



            if th.id not in self.state.combined.exempt["threads"]:



                self.state.combined.exempt["threads"].append(th.id)



        if parent and parent.id not in self.state.combined.exempt["channels"]:



            self.state.combined.exempt["channels"].append(parent.id)







        empty_model = (self.state.model.pos_docs + self.state.model.neg_docs) == 0 if self.state.model else True



        if empty_model and phish_threads:



            await self._scan_thread_tokens(phish_threads[0], "phish")



        if empty_model and blacklist_threads:



            await self._scan_thread_tokens(blacklist_threads[0], "safe")







        if wl_threads and not (self.state.combined.whitelist["dhash64"] or self.state.combined.whitelist["sha1k"]):



            await self._scan_thread_wl(wl_threads[0])







        changed = await self._phash_reconcile(parent, phish_threads)



        if changed:



            try:



                th = await self.state._ensure_thread()



                if th:



                    await th.send(f"🧩 pHash reconcile: {changed} hash di‑whitelist (anti false positive).")



            except Exception:



                pass







        await self.state.save_snapshot()











async def setup(bot: commands.Bot):



    await bot.add_cog(SelfLearningGuard(bot))



