# -*- coding: utf-8 -*-
"""
SatpamBot • FirstTouchAttachmentBan
Version: v11.4+ (combined v11.3 + v11.4)
- v11.3: PACK pattern direct-ban (1.jpg 2.jpg 3.jpg 4.webp / image.* + 2/3/4), ref-index, pHash, auto-whitelist, auto-delete.
- v11.4: MIME sniff (magic bytes) & extension-mismatch burst → direct-ban, pack detection now respects true image kind.
"""
from __future__ import annotations
import json, os, hashlib, re, io
from typing import Optional, Dict, Any, Set, List, Tuple
import discord
from discord.ext import commands

HARD = {
    "enabled": True,
    "always": True,
    "only_roleless": False,
    "exempt_staff": True,
    "exempt_role_names": [],
    "exempt_role_ids": [],
    "whitelist_channels": [],
    "delete_message_days": 7,

    "safety_required": True,
    "reference_required_for_ban": True,
    "reference_thread_name": "imagephising",
    "reference_cache_minutes": 15,
    "phash_min_threshold": 0.90,
    "phash_strong_threshold": 0.93,
    "direct_ban_on_strong": True,

    "log_channel_name": "log-botphising",
    "log_channel_id": 0,
    "fp_log_thread_name": "imagephising-fp-log",
    "ban_log_thread_name": "Ban Log",
    "whitelist_thread_name": "whitelist",

    "whitelist_file": "config/image_whitelist_sha256.json",
    "skip_logging_if_whitelisted": True,
    "auto_whitelist_enabled": True,
    "auto_whitelist_if_phash_below": 0.85,
    "auto_whitelist_log_to_thread": True,

    "auto_delete_logs_enabled": True,
    "auto_delete_logs_seconds": 600,
    "auto_delete_fp_thread": True,
    "auto_delete_whitelist_thread": True,
    "auto_delete_ban_thread": False,
    "auto_delete_parent_log_channel": False,

    "preemptive_timeout_enabled": True,
    "preemptive_timeout_seconds": 300,

    # v11.3 PACK pattern
    "pattern_pack_ban_enabled": True,
    "pattern_pack_direct_ban": True,
    "pattern_pack_min_attachments": 3,
    "pattern_pack_digits": [1,2,3,4,5,6],
    "pattern_pack_allow_image_prefix": True,
    "pattern_pack_exts": ["jpg","jpeg","png","webp"],

    # v11.4 MIME sniff
    "mime_sniff_enabled": True,
    "mime_direct_ban_enabled": True,
    "mime_direct_ban_min_mismatches": 2,
    "image_kinds": ["jpeg","png","webp","gif"],
}

CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "..", "..",
    "config", "first_touch_attachment_ban.json"
)

def _load_cfg() -> Dict[str, Any]:
    try:
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            d = json.load(f)
            if isinstance(d, dict):
                return d
    except Exception:
        pass
    return {}

def _cfg_get(cfg: Dict[str, Any], key: str):
    return cfg.get(key, HARD[key])

def _utcnow():
    import datetime
    return datetime.datetime.now(datetime.timezone.utc)

async def _maybe_await(x):
    if hasattr(x, "__await__"):
        return await x
    return x

# === MIME sniff helpers ===
def _sniff_image_kind(b: bytes) -> str:
    if not b or len(b) < 12:
        return "unknown"
    if b.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if b[0:2] == b"\xFF\xD8":
        return "jpeg"
    if b.startswith(b"GIF87a") or b.startswith(b"GIF89a"):
        return "gif"
    if b.startswith(b"RIFF") and b[8:12] == b"WEBP":
        return "webp"
    return "unknown"

def _name_parts(name: str) -> Tuple[str, str]:
    n = name.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip().lower()
    if "." in n: stem, ext = n.rsplit(".", 1)
    else: stem, ext = n, ""
    return stem, ext

class FirstTouchAttachmentBan(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        cfg = _load_cfg()

        self.enabled = bool(_cfg_get(cfg, "enabled"))
        self.always = bool(_cfg_get(cfg, "always"))
        self.only_roleless = bool(_cfg_get(cfg, "only_roleless"))
        self.exempt_staff = bool(_cfg_get(cfg, "exempt_staff"))
        self.exempt_role_names = {str(x).lower() for x in _cfg_get(cfg, "exempt_role_names") or []}
        self.exempt_role_ids = {int(x) for x in _cfg_get(cfg, "exempt_role_ids") or []}
        self.whitelist_channels = {str(x).lower() for x in _cfg_get(cfg, "whitelist_channels") or []}
        self.delete_message_days = int(_cfg_get(cfg, "delete_message_days"))

        self.safety_required = bool(_cfg_get(cfg, "safety_required"))
        self.reference_required_for_ban = bool(_cfg_get(cfg, "reference_required_for_ban"))
        self.reference_thread_name = str(_cfg_get(cfg, "reference_thread_name"))
        self.reference_cache_minutes = int(_cfg_get(cfg, "reference_cache_minutes"))
        self.phash_min_threshold = float(_cfg_get(cfg, "phash_min_threshold"))
        self.phash_strong_threshold = float(_cfg_get(cfg, "phash_strong_threshold"))
        self.direct_ban_on_strong = bool(_cfg_get(cfg, "direct_ban_on_strong"))

        self.log_channel_name = str(_cfg_get(cfg, "log_channel_name") or "")
        lcid = int(_cfg_get(cfg, "log_channel_id") or 0)
        self._log_channel_id = lcid if lcid > 0 else None
        self.fp_log_thread_name = str(_cfg_get(cfg, "fp_log_thread_name") or "")
        self.ban_log_thread_name = str(_cfg_get(cfg, "ban_log_thread_name") or "")
        self.whitelist_thread_name = str(_cfg_get(cfg, "whitelist_thread_name") or "")

        self.whitelist_file = str(_cfg_get(cfg, "whitelist_file"))
        self.skip_logging_if_whitelisted = bool(_cfg_get(cfg, "skip_logging_if_whitelisted"))
        self.auto_whitelist_enabled = bool(_cfg_get(cfg, "auto_whitelist_enabled"))
        self.auto_whitelist_if_phash_below = float(_cfg_get(cfg, "auto_whitelist_if_phash_below"))
        self.auto_whitelist_log_to_thread = bool(_cfg_get(cfg, "auto_whitelist_log_to_thread"))

        self.auto_delete_logs_enabled = bool(_cfg_get(cfg, "auto_delete_logs_enabled"))
        self.auto_delete_logs_seconds = int(_cfg_get(cfg, "auto_delete_logs_seconds"))
        self.auto_delete_fp_thread = bool(_cfg_get(cfg, "auto_delete_fp_thread"))
        self.auto_delete_whitelist_thread = bool(_cfg_get(cfg, "auto_delete_whitelist_thread"))
        self.auto_delete_ban_thread = bool(_cfg_get(cfg, "auto_delete_ban_thread"))
        self.auto_delete_parent_log_channel = bool(_cfg_get(cfg, "auto_delete_parent_log_channel"))

        self.preemptive_timeout_enabled = bool(_cfg_get(cfg, "preemptive_timeout_enabled"))
        self.preemptive_timeout_seconds = int(_cfg_get(cfg, "preemptive_timeout_seconds"))

        self.pattern_pack_ban_enabled = bool(_cfg_get(cfg, "pattern_pack_ban_enabled"))
        self.pattern_pack_direct_ban = bool(_cfg_get(cfg, "pattern_pack_direct_ban"))
        self.pattern_pack_min_attachments = int(_cfg_get(cfg, "pattern_pack_min_attachments"))
        self.pattern_pack_digits = [int(x) for x in (_cfg_get(cfg, "pattern_pack_digits") or [])]
        self.pattern_pack_allow_image_prefix = bool(_cfg_get(cfg, "pattern_pack_allow_image_prefix"))
        self.pattern_pack_exts = {str(x).lower() for x in (_cfg_get(cfg, "pattern_pack_exts") or [])}

        self.mime_sniff_enabled = bool(_cfg_get(cfg, "mime_sniff_enabled"))
        self.mime_direct_ban_enabled = bool(_cfg_get(cfg, "mime_direct_ban_enabled"))
        self.mime_direct_ban_min_mismatches = int(_cfg_get(cfg, "mime_direct_ban_min_mismatches"))
        self.image_kinds = {str(x).lower() for x in (_cfg_get(cfg, "image_kinds") or [])}

        self._wl_cache: Set[str] = set()
        self._ref_cache: Dict[int, Dict[str, Any]] = {}
        self._load_whitelist()

    def _load_whitelist(self):
        try:
            with open(self.whitelist_file, "r", encoding="utf-8") as f:
                d = json.load(f)
                if isinstance(d, list):
                    self._wl_cache = {str(x) for x in d}
                elif isinstance(d, dict) and "sha256" in d:
                    self._wl_cache = {str(x) for x in d.get("sha256", [])}
        except Exception:
            self._wl_cache = set()

    def _save_whitelist(self):
        try:
            os.makedirs(os.path.dirname(self.whitelist_file), exist_ok=True)
            with open(self.whitelist_file, "w", encoding="utf-8") as f:
                json.dump(sorted(list(self._wl_cache)), f, indent=2)
        except Exception:
            pass

    def _resolve_log_channel(self, guild: discord.Guild) -> Optional[discord.TextChannel]:
        if self._log_channel_id:
            ch = guild.get_channel(self._log_channel_id)
            if isinstance(ch, discord.TextChannel): return ch
        if self.log_channel_name:
            ch = discord.utils.get(guild.text_channels, name=self.log_channel_name)
            if isinstance(ch, discord.TextChannel): return ch
        for name in ("log-botphising", "log-satpam", "logs", "moderation-log"):
            ch = discord.utils.get(guild.text_channels, name=name)
            if isinstance(ch, discord.TextChannel): return ch
        return None

    def _find_thread(self, guild: discord.Guild, parent: Optional[discord.TextChannel], name: str) -> Optional[discord.Thread]:
        if not name: return None
        if parent:
            for th in parent.threads:
                if th.name.lower() == name.lower(): return th
        try:
            for th in guild.threads:
                if th.name.lower() == name.lower() and (parent is None or th.parent_id == parent.id):
                    return th
        except Exception:
            pass
        return None

    def _delete_after_for(self, tag: str) -> Optional[float]:
        if not self.auto_delete_logs_enabled: return None
        flags = {
            "fp": self.auto_delete_fp_thread,
            "whitelist": self.auto_delete_whitelist_thread,
            "ban": self.auto_delete_ban_thread,
            "parent": self.auto_delete_parent_log_channel,
        }
        return float(self.auto_delete_logs_seconds) if flags.get(tag, False) else None

    async def _send_log(self, guild: discord.Guild, embed: discord.Embed, *, thread: Optional[discord.Thread]=None, delete_after: Optional[float]=None):
        ch = self._resolve_log_channel(guild)
        if not ch: return None
        try:
            if thread:
                return await thread.send(embed=embed, delete_after=delete_after) if delete_after else await thread.send(embed=embed)
            return await ch.send(embed=embed, delete_after=delete_after) if delete_after else await ch.send(embed=embed)
        except Exception:
            return None

    async def _attachment_meta(self, a: discord.Attachment) -> Dict[str, Any]:
        stem, ext = _name_parts(a.filename or "")
        ext = ext.lower()
        meta: Dict[str, Any] = {"stem": stem, "ext": ext, "kind": "unknown", "sha256": None, "bytes": 0}
        try:
            b = await a.read()
            meta["bytes"] = len(b)
            meta["sha256"] = hashlib.sha256(b).hexdigest()
            if self.mime_sniff_enabled:
                meta["kind"] = _sniff_image_kind(b)
        except Exception:
            pass
        ct = getattr(a, "content_type", None)
        if ct and meta["kind"] == "unknown":
            if "png" in ct: meta["kind"] = "png"
            elif "jpeg" in ct or "jpg" in ct: meta["kind"] = "jpeg"
            elif "gif" in ct: meta["kind"] = "gif"
            elif "webp" in ct: meta["kind"] = "webp"
        meta["ext_mismatch"] = (meta["kind"] in {"jpeg","png","gif","webp"} and ext not in {meta["kind"], "jpg", "jpeg"} if ext else False)
        return meta

    def _pack_pattern(self, metas: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not self.pattern_pack_ban_enabled or len(metas) < self.pattern_pack_min_attachments:
            return {"matched": False}
        is_image = []
        for m in metas:
            if m["kind"] in self.image_kinds: is_image.append(True)
            else: is_image.append(m["ext"] in self.pattern_pack_exts)
        if sum(is_image) < self.pattern_pack_min_attachments:
            return {"matched": False}

        stems = [m["stem"] for m in metas]
        exts = [m["ext"] for m in metas]
        kinds = [m["kind"] for m in metas]

        digits = {str(d) for d in self.pattern_pack_digits}
        numeric = {s for s in stems if s in digits}
        has_image_prefix = "image" in stems

        rule_a = len(numeric) >= 3
        numeric_24 = {s for s in stems if s in {"2","3","4"}}
        rule_b = self.pattern_pack_allow_image_prefix and has_image_prefix and len(numeric_24) >= 2

        if rule_a or rule_b:
            return {"matched": True, "rule": "A" if rule_a else "B", "stems": stems, "kinds": kinds, "exts": exts}
        return {"matched": False}

    async def _build_reference_index(self, guild: discord.Guild) -> Dict[str, Any]:
        parent = self._resolve_log_channel(guild)
        ref_thread = self._find_thread(guild, parent, self.reference_thread_name)
        hashes = set()
        if not ref_thread:
            return {"hashes": hashes, "count": 0}
        try:
            async for msg in ref_thread.history(limit=None, oldest_first=True):
                for att in getattr(msg, "attachments", []):
                    try:
                        b = await att.read()
                        h = hashlib.sha256(b).hexdigest(); hashes.add(h)
                    except Exception:
                        continue
        except Exception:
            pass
        return {"hashes": hashes, "count": len(hashes)}

    async def _get_reference_index(self, guild: discord.Guild) -> Dict[str, Any]:
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc)
        entry = self._ref_cache.get(guild.id)
        if entry and (now - entry["ts"]).total_seconds() <= self.reference_cache_minutes * 60:
            return entry
        idx = await self._build_reference_index(guild)
        self._ref_cache[guild.id] = {"hashes": idx["hashes"], "count": idx["count"], "ts": now}
        return self._ref_cache[guild.id]

    async def _phash_quick(self, message: discord.Message) -> float:
        best = 0.0
        cogs = ("AntiImagePhashRuntime","PhashAutoBan","AntiImagePhishAdvanced","AntiImagePhishGuard")
        fns  = ("check_attachment","is_phish_attachment","phash_check","classify_attachment","score_attachment")
        for a in message.attachments:
            for cn in cogs:
                cog = self.bot.get_cog(cn)
                if not cog: continue
                for fn in fns:
                    func = getattr(cog, fn, None)
                    if not callable(func): continue
                    try:
                        res = func(attachment=a, message=message, author=message.author, channel=message.channel)
                        res = await _maybe_await(res)
                    except TypeError:
                        try:
                            res = func(a, message); res = await _maybe_await(res)
                        except Exception:
                            continue
                    except Exception:
                        continue
                    try:
                        if isinstance(res, dict):
                            conf = res.get("confidence") or res.get("score") or res.get("ratio")
                            if conf is None and "distance" in res: conf = 1.0 - float(res["distance"])/64.0
                        elif isinstance(res, (list, tuple)) and res and isinstance(res[0], (int,float)):
                            conf = float(res[0])
                        elif isinstance(res, (int,float)): conf = float(res)
                        elif isinstance(res, bool): conf = 1.0 if res else 0.0
                        else: conf = None
                        if conf is not None:
                            best = max(best, float(conf)); break
                    except Exception:
                        continue
                if best >= self.phash_strong_threshold:
                    break
        return best

    async def _ban_direct(self, member: discord.Member, reason: str):
        try:
            try:
                await member.guild.ban(member, reason=reason,
                    delete_message_seconds=min(7*24*3600, self.delete_message_days*24*3600))
            except TypeError:
                await member.guild.ban(member, reason=reason, delete_message_days=min(7, self.delete_message_days))
        except Exception:
            raise

    async def act_on_message(self, message: discord.Message):
        if not self.enabled or not message.guild or message.author.bot or not message.attachments:
            return
        member: discord.Member = message.author  # type: ignore
        if self.only_roleless and getattr(member, "roles", None):
            if len(member.roles) > 1: return
        if self.exempt_staff and any(r.permissions.kick_members or r.permissions.ban_members for r in getattr(member,"roles",[])):
            return
        if any(r.name.lower() in self.exempt_role_names or r.id in self.exempt_role_ids for r in getattr(member,"roles",[])):
            return
        if str(getattr(message.channel,"name","")).lower() in self.whitelist_channels:
            return

        guild = message.guild
        parent = self._resolve_log_channel(guild)
        ban_thread = self._find_thread(guild, parent, self.ban_log_thread_name)
        fp_thread  = self._find_thread(guild, parent, self.fp_log_thread_name)
        wl_thread  = self._find_thread(guild, parent, self.whitelist_thread_name)

        metas: List[Dict[str, Any]] = [await self._attachment_meta(a) for a in message.attachments]

        # v11.4: MIME mismatch burst
        if self.mime_sniff_enabled and self.mime_direct_ban_enabled:
            mismatches = sum(1 for m in metas if m.get("ext_mismatch"))
            if mismatches >= self.mime_direct_ban_min_mismatches:
                e = discord.Embed(
                    title="MIME/Ext mismatch burst → BAN LANGSUNG",
                    description=(f"{mismatches} file mismatch (nama .jpg/.png tapi isi WEBP/tt lainnya)\\n"
                                 f"Channel: {message.channel.mention} • User: {member.mention} (`{member.id}`)"),
                    color=0xE74C3C, timestamp=_utcnow(),
                )
                e.url = getattr(message, "jump_url", discord.Embed.Empty)
                e.set_footer(text="SatpamBot • FTAB v11.4+")
                await self._send_log(guild, e, thread=ban_thread, delete_after=self._delete_after_for('ban'))
                await self._ban_direct(member, "Satpam: MIME/Ext mismatch pack")
                return

        # v11.3: PACK pattern
        pack = self._pack_pattern(metas)
        if pack.get("matched"):
            e = discord.Embed(
                title="Pattern PACK terdeteksi → BAN LANGSUNG",
                description=(f"Rule={pack.get('rule')} • stems={', '.join(pack.get('stems', []))}\\n"
                             f"Channel: {message.channel.mention} • User: {member.mention} (`{member.id}`)"),
                color=0xE74C3C, timestamp=_utcnow()
            )
            e.url = getattr(message, "jump_url", discord.Embed.Empty)
            e.set_footer(text="SatpamBot • FTAB v11.4+")
            await self._send_log(guild, e, thread=ban_thread, delete_after=self._delete_after_for('ban'))
            await self._ban_direct(member, "Satpam: PACK image spam")
            return

        # Reference exact
        ref = await self._get_reference_index(guild)
        ref_hashes: Set[str] = set(ref["hashes"])
        exact_hit = any((m.get("sha256") in ref_hashes) for m in metas if m.get("sha256"))

        if exact_hit or not self.reference_required_for_ban:
            base = discord.Embed(
                title="First-touch detected",
                description=(f"RefThread='{self.reference_thread_name}' entries={ref['count']} | exact_hit={exact_hit}\\n"
                             f"Channel: {message.channel.mention} • User: {member.mention} (`{member.id}`)"),
                color=0x3498DB, timestamp=_utcnow(),
            )
            base.url = getattr(message,"jump_url", discord.Embed.Empty)
            base.set_footer(text="SatpamBot • FTAB v11.4+")
            await self._send_log(guild, base, thread=ban_thread, delete_after=self._delete_after_for('ban'))

            if self.preemptive_timeout_enabled and self.preemptive_timeout_seconds > 0:
                try:
                    from datetime import datetime, timezone, timedelta
                    until = datetime.now(timezone.utc) + timedelta(seconds=self.preemptive_timeout_seconds)
                    if hasattr(member, "timeout"):
                        await member.timeout(until, reason="Satpam: pending autoban (reference exact)")
                except Exception:
                    pass

            submitted = False
            for cog_name in ("AutobanSafetyInterceptor", "BanQueueWatcher"):
                cog = self.bot.get_cog(cog_name)
                if not cog: continue
                for meth in ("request_ban","enqueue_ban","enqueue","queue_ban","submit"):
                    fn = getattr(cog, meth, None)
                    if callable(fn):
                        try:
                            res = fn(member=member, reason="First-touch (reference)", delete_message_days=self.delete_message_days,
                                     metadata={"labels":["first_touch","reference_exact","v11.4+"],
                                               "sha256":[m.get("sha256") for m in metas if m.get("sha256")]})
                            await _maybe_await(res); submitted=True; break
                        except Exception:
                            continue
                if submitted: break
            if not submitted and not self.safety_required:
                await self._ban_direct(member, "Satpam: First-touch (reference exact)")
            return

        # pHash strong
        best = await self._phash_quick(message)
        if self.direct_ban_on_strong and best >= self.phash_strong_threshold:
            info = discord.Embed(
                title="Strong pHash match → BAN",
                description=(f"best_conf={best:.3f} ≥ {self.phash_strong_threshold:.2f}\\n"
                             f"Channel: {message.channel.mention} • User: {member.mention} (`{member.id}`)"),
                color=0xE74C3C, timestamp=_utcnow(),
            )
            info.url = getattr(message,"jump_url", discord.Embed.Empty)
            info.set_footer(text="SatpamBot • FTAB v11.4+")
            await self._send_log(guild, info, thread=ban_thread, delete_after=self._delete_after_for('ban'))

            if self.preemptive_timeout_enabled and self.preemptive_timeout_seconds > 0:
                try:
                    from datetime import datetime, timezone, timedelta
                    until = datetime.now(timezone.utc) + timedelta(seconds=self.preemptive_timeout_seconds)
                    if hasattr(member, "timeout"):
                        await member.timeout(until, reason="Satpam: pending autoban (pHash strong)")
                except Exception:
                    pass

            submitted = False
            for cog_name in ("AutobanSafetyInterceptor", "BanQueueWatcher"):
                cog = self.bot.get_cog(cog_name)
                if not cog: continue
                for meth in ("request_ban","enqueue_ban","enqueue","queue_ban","submit"):
                    fn = getattr(cog, meth, None)
                    if callable(fn):
                        try:
                            res = fn(member=member, reason="First-touch (pHash strong)", delete_message_days=self.delete_message_days,
                                     metadata={"labels":["first_touch","phash_strong","v11.4+"], "phash_best_conf": best})
                            await _maybe_await(res); submitted=True; break
                        except Exception:
                            continue
                if submitted: break
            if not submitted and not self.safety_required:
                await self._ban_direct(member, "Satpam: First-touch (pHash strong)")
            return

        # Non-phish → auto-whitelist bila pHash rendah
        if self.auto_whitelist_enabled and best < self.auto_whitelist_if_phash_below:
            added = 0
            for m in metas:
                h = m.get("sha256")
                if h and h not in self._wl_cache:
                    self._wl_cache.add(h); added += 1
            if added: self._save_whitelist()
            if self.auto_whitelist_log_to_thread:
                emb = discord.Embed(
                    title="Auto-whitelist (non-phish)",
                    description=(f"pHash best_conf={best:.3f} < {self.auto_whitelist_if_phash_below:.2f}\\n"
                                 f"Origin: {getattr(message,'jump_url','n/a')}"),
                    color=0x2ECC71, timestamp=_utcnow(),
                )
                await self._send_log(guild, emb, thread=wl_thread, delete_after=self._delete_after_for('whitelist'))
            return

        # FP review fallback
        fp = discord.Embed(
            title="Skip ban: no exact/strong match",
            description=(f"pHash best_conf={best:.3f}. Kirim ke FP thread untuk review."),
            color=0xF1C40F, timestamp=_utcnow(),
        )
        fp.url = getattr(message,"jump_url", discord.Embed.Empty)
        fp.set_footer(text="SatpamBot • FTAB v11.4+")
        await self._send_log(guild, fp, thread=fp_thread, delete_after=self._delete_after_for("fp"))

async def setup(bot: commands.Bot):
    if bot.get_cog("FirstTouchAttachmentBan") is None:
        await bot.add_cog(FirstTouchAttachmentBan(bot))
