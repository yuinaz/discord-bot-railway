
from __future__ import annotations
"""
testban_sim.py — fast path
- Uses the same poster/icon helper as real ban
"""
import discord
from discord.ext import commands
import asyncio

try:
    from modules.discord_bot.helpers.ban_poster import render_to_buffer_async, poster_enabled, poster_icon_mode, load_icon_bytes
except Exception:
    async def render_to_buffer_async(username: str, mode: str="ban"): return None
    def poster_enabled(): return False
    def poster_icon_mode(): return False
    def load_icon_bytes(size: int = 192): return None

class TestBanSim(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.command(name="testban")
    @commands.has_permissions(kick_members=True)
    async def testban(self, ctx: commands.Context, *, user_mention: str = ""):
        user = ctx.author if not user_mention else ctx.author  # simulate on author for demo
        icon_buf = None
        poster_task = None
        if poster_enabled():
            if poster_icon_mode():
                icon_buf = load_icon_bytes(160)
            else:
                poster_task = asyncio.create_task(render_to_buffer_async(getattr(user, "display_name", str(user)), mode="testban"))
        await ctx.reply("🚧 Simulasi ban diproses…", mention_author=False)
        try:
            if icon_buf is not None:
                file = discord.File(icon_buf, filename="fibi_icon.png")
                embed = discord.Embed(colour=discord.Colour.green(), title="Simulasi Ban — Sukses")
                embed.set_thumbnail(url="attachment://fibi_icon.png")
                await ctx.send(file=file, embed=embed)
                return
            if poster_task:
                buf = await poster_task
                if buf is not None:
                    file = discord.File(buf, filename="ban_card.png")
                    embed = discord.Embed(colour=discord.Colour.green(), title="Simulasi Ban — Sukses")
                    embed.set_image(url="attachment://ban_card.png")
                    await ctx.send(file=file, embed=embed)
                    return
        except Exception:
            pass
        await ctx.send("✅ Simulasi ban selesai (poster nonaktif).")

async def setup(bot: commands.Bot):
    await bot.add_cog(TestBanSim(bot))
