async def handle_urls(message, bot):
    # (optional) placeholder; you can implement phishing URL rules here.
    return
