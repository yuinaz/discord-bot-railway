import os
import logging
from typing import List

import discord
from discord.ext import tasks, commands

log = logging.getLogger(__name__)

# Server default + interval (WIB +7 ditangani di sisi penampil)
GUILD_ID_DEFAULT = 761163966030151701  # LeinDiscord
INTERVAL_DEFAULT_SEC = int(os.environ.get("LIVE_METRICS_INTERVAL", "60"))  # 60s anti spam

def _guild_ids(bot: commands.Bot) -> List[int]:
    env = os.environ.get("DISCORD_GUILD_ID", "").strip()
    if env:
        try:
            return [int(x) for x in env.replace(",", " ").split() if x.strip().isdigit()]
        except Exception:
            pass
    if bot.guilds:
        return [g.id for g in bot.guilds]
    return [GUILD_ID_DEFAULT]

class LiveMetrics(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.loop.start()

    def cog_unload(self):
        self.loop.cancel()

    @tasks.loop(seconds=INTERVAL_DEFAULT_SEC)
    async def loop(self):
        gids = _guild_ids(self.bot)
        try:
            for gid in gids:
                guild = self.bot.get_guild(gid)
                if not guild:
                    continue
                members = guild.member_count or 0
                online = sum(1 for m in guild.members if m.status and m.status != discord.Status.offline)
                latency_ms = int(self.bot.latency * 1000) if self.bot.latency else 0

                try:
                    from satpambot.dashboard import live_store as _ls  # type: ignore
                    _ls.STATS = {
                        "member_count": members,
                        "online_count": online,
                        "latency_ms": latency_ms,
                    }
                except Exception:
                    pass

            log.info("[live_metrics] loop every %ss guilds=%s default_gid=%s",
                     INTERVAL_DEFAULT_SEC, gids, GUILD_ID_DEFAULT)
        except Exception as e:
            log.exception("live_metrics error: %s", e)

async def setup(bot: commands.Bot):
    await bot.add_cog(LiveMetrics(bot))
