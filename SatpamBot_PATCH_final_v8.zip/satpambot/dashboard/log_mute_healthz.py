"""
Filter logger untuk membungkam spam /healthz dan /uptime
di werkzeug, gunicorn.access, uvicorn.access.
"""
import logging
import re

_PATH_PAT = re.compile(r"\s/(healthz|uptime)\b")

class _MuteHealth(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        msg = getattr(record, "msg", "") or ""
        if isinstance(msg, (bytes, bytearray)):
            try:
                msg = msg.decode("utf-8", "ignore")
            except Exception:
                msg = str(msg)
        line = f"{msg} {getattr(record, 'args', '')}"
        return _PATH_PAT.search(line) is None

def _install(name: str) -> None:
    try:
        lg = logging.getLogger(name)
        lg.addFilter(_MuteHealth())
    except Exception:
        pass

for _n in ("werkzeug", "gunicorn.access", "uvicorn.access"):
    _install(_n)
