from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Iterable

# Bungkam log /healthz & /uptime (aman dipanggil berulang)
try:
    import satpambot.dashboard.log_mute_healthz  # noqa: F401
except Exception:
    pass

from flask import (
    Blueprint, current_app, request, redirect, url_for,
    render_template, send_from_directory, jsonify,
    make_response
)
from markupsafe import Markup

PKG_DIR = Path(__file__).resolve().parent
THEMES_DIR = PKG_DIR / "themes"


def _ui_cfg() -> Dict[str, Any]:
    cfg = dict(current_app.config.get("UI_CFG") or {})
    cfg.setdefault("theme", "gtake")
    cfg.setdefault("accent", "#3b82f6")
    return cfg


def _first_file(files: Iterable) -> Any | None:
    for f in files:
        if f and getattr(f, "filename", ""):
            return f
    return None


bp = Blueprint(
    "dashboard", __name__,
    url_prefix="/dashboard",
    template_folder="templates",
    static_folder="static",
    static_url_path="/dashboard-static",
)
bp_theme = Blueprint("dashboard_theme", __name__, url_prefix="/dashboard-theme")


@bp.get("/")
def home():
    cfg = _ui_cfg()
    return render_template("dashboard.html", title="Dashboard", cfg=cfg)


@bp.get("/login")
def login_get():
    """
    JANGAN ubah templates/login.html.
    Kita injeksi wrapper .lg-card + CSS TANPA merusak struktur aslinya.
    """
    cfg = _ui_cfg()
    html = render_template("login.html", title="Login", cfg=cfg)

    low = html.lower()

    # Tambahkan login_exact.css di <head> bila belum ada
    if "login_exact.css" not in low:
        css_tag = '<link rel="stylesheet" href="/dashboard-static/css/login_exact.css?v=13">'
        if "<head>" in low:
            html = re.sub(r"(?i)<head>", "<head>\n  " + css_tag + "\n", html, count=1)
        else:
            # fallback: bungkus sederhana
            html = f"<!doctype html><html><head>{css_tag}</head><body>{html}</body></html>"

    # Tambahkan class login-body pada <body> agar CSS bisa menargetkan form lama
    if "<body" in low and "login-body" not in low:
        # jika tidak ada class, tambahkan
        html = re.sub(r'(?i)<body(?![^>]*class=)',
                      '<body class="login-body"',
                      html, count=1)
        # jika sudah ada class, selipkan login-body
        html = re.sub(r'(?i)<body([^>]*class=")([^"]*)(")',
                      lambda m: f'<body{m.group(1)}{m.group(2)} login-body{m.group(3)}',
                      html, count=1)

    # Pastikan ada wrapper .lg-card minimal sekali;
    # jika belum ada, sisipkan section sesudah <body> dan sebelum </body>
    if "lg-card" not in low:
        start = re.search(r"(?i)<body[^>]*>", html)
        end = re.search(r"(?i)</body>", html)
        if start and end:
            i, j = start.end(), end.start()
            inner = html[i:j]
            shell_open = '<section class="login-card lg-card">'
            shell_close = "</section>"
            html = html[:i] + shell_open + inner + shell_close + html[j:]

    return make_response(Markup(html))


@bp.post("/login")
def login_post():
    # auth sudah ditangani sistem anda; redirect ke dashboard
    return redirect(url_for("dashboard.home"))


@bp.get("/settings")
def settings_get():
    cfg = _ui_cfg()
    return render_template("settings.html", title="Settings", cfg=cfg)


@bp.get("/security")
def security_get():
    """
    Render security.html dan PASTIKAN tersedia dropzone drag&drop standar
    untuk upload phish image -> phash.
    """
    cfg = _ui_cfg()
    html = render_template("security.html", title="Security", cfg=cfg)
    low = html.lower()

    tokens = ("drag&drop", "drag and drop", 'class="dragdrop"',
              'id="sec-dropzone"', "id='sec-dropzone'")
    if all(tok not in low for tok in tokens):
        html += '''
<div id="sec-dropzone" class="dragdrop">drag&drop</div>
<script>
(function(){
  const dz = document.getElementById('sec-dropzone');
  if(!dz) return;
  function stop(e){e.preventDefault(); e.stopPropagation();}
  ['dragenter','dragover','dragleave','drop'].forEach(ev=>dz.addEventListener(ev, stop));
  dz.addEventListener('dragover', () => dz.classList.add('hover'));
  dz.addEventListener('dragleave', () => dz.classList.remove('hover'));
  dz.addEventListener('drop', async (e) => {
    dz.classList.remove('hover');
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if(!f){ alert('No file'); return; }
    const fd = new FormData(); fd.append('file', f, f.name);
    const res = await fetch('/dashboard/security/upload', {method:'POST', body: fd});
    try{
      const js = await res.json();
      console.log('upload result:', js);
    }catch(err){ console.warn('upload parse error', err); }
  });
})();
</script>
<style>
.dragdrop{
  border:2px dashed rgba(255,255,255,.2); border-radius:14px;
  min-height:120px; display:flex; align-items:center; justify-content:center;
  font:600 14px/1.2 Inter, system-ui, -apple-system, Segoe UI, Arial;
  color:#cbd5e1; background:rgba(15,23,42,.35); margin:12px 0;
}
.dragdrop.hover{ background: rgba(59,130,246,.15); color:white; }
</style>
'''
    return make_response(Markup(html))


@bp.post("/upload")
def upload_any():
    f = _first_file(request.files.values())
    if not f:
        return jsonify({"ok": False, "error": "no file"}), 400
    return jsonify({"ok": True, "filename": f.filename})


@bp.post("/security/upload")
def upload_security():
    f = _first_file(request.files.values())
    if not f:
        return jsonify({"ok": False, "error": "no file"}), 400
    # TODO: panggil pipeline phash disini bila perlu
    return jsonify({"ok": True, "filename": f.filename})


@bp.get("/api/metrics")
def api_metrics_proxy():
    try:
        from satpambot.dashboard import live_store as _ls  # type: ignore
        data = getattr(_ls, "STATS", {}) or {}
        return jsonify(data)
    except Exception:
        return jsonify({
            "member_count": 0,
            "online_count": 0,
            "latency_ms": 0,
            "cpu": 0.0,
            "ram": 0.0,
        })


@bp_theme.get("/<theme>/<path:filename>")
def theme_static(theme: str, filename: str):
    root = THEMES_DIR / theme / "static"
    return send_from_directory(str(root), filename)


def register_webui_builtin(app):
    app.register_blueprint(bp)
    app.register_blueprint(bp_theme)

    @app.get("/")
    def _root_redirect():
        return redirect("/dashboard")

    @app.get("/login")
    def _alias_login():
        return redirect("/dashboard/login")

    @app.get("/settings")
    def _alias_settings():
        return redirect("/dashboard/settings")

    @app.get("/security")
    def _alias_security():
        return redirect("/dashboard/security")


__all__ = ["bp", "bp_theme", "register_webui_builtin"]
