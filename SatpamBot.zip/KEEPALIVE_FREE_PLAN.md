# Free Plan Keep-Alive (UptimeRobot)
Setup UptimeRobot monitor (HTTP GET) ke `https://<app>.onrender.com/uptime` setiap 10–14 menit.
Endpoint `/uptime` sudah tersedia dan lognya dibisukan.
