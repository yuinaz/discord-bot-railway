
# Quick import test
import importlib
m = importlib.import_module("satpambot.bot.modules.discord_bot.cogs.a08_public_clearchat")
print("clearchat hybrid cog import OK:", m.__file__)
