import os
from typing import Optional
import base64, logging
log = logging.getLogger(__name__)

def _cfg(key, default=None):
    try:
        from satpambot.config.runtime import cfg
        v = cfg(key)
        return default if v is None else v
    except Exception:
        return default

def _b64(b: bytes) -> str:
    import base64 as _b; return _b.b64encode(b).decode()

def answer(image_bytes: bytes, prompt: str) -> str:
    if provider == "openai":
        try:
            from openai import OpenAI
            client = OpenAI(api_key=_cfg("OPENAI_API_KEY"))
            url = "data:image/png;base64," + _b64(image_bytes)
