# -*- coding: utf-8 -*-
from __future__ import annotations
import os, asyncio, json, logging, contextlib
from pathlib import Path
from typing import Optional, List, Tuple

import discord
from discord.ext import commands, tasks

from satpambot.bot.modules.discord_bot.helpers.thread_utils import ensure_neuro_thread, DEFAULT_THREAD_NAME

log = logging.getLogger(__name__)

DEFAULT_MEM_FILES: List[Path] = [
    Path("data/learn_progress_junior.json"),
    Path("data/learn_progress_senior.json"),
]
EXTRA_GLOBS = ["data/learn_progress_*.json"]
KEEPER_KEY = "[neuro-lite:memory]"
MARKER = "<!-- [neuro-lite:memory] -->"  # untuk identifikasi & edit in-place
ALLOW_SEND_FALLBACK = os.getenv("NEURO_MEMORY_SEND_FALLBACK", "1") not in ("0","false","False","no","No")
CLEANUP_DELETE = os.getenv("NEURO_MEMORY_CLEANUP_DELETE", "0") in ("1","true","True","yes","Y")

def _discover_mem_paths() -> List[Path]:
    paths = list(DEFAULT_MEM_FILES)
    for pat in EXTRA_GLOBS:
        for p in sorted(Path(".").glob(pat)):
            if p not in paths:
                paths.append(p)
    return paths

def _load_memory_json() -> str:
    merged = {}
    any_found = False
    for p in _discover_mem_paths():
        try:
            if p.exists():
                any_found = True
                d = json.loads(p.read_text(encoding="utf-8"))
                merged[p.name] = d
        except Exception as e:
            merged[p.name] = {"error": str(e)}
    if not any_found:
        merged = {"status": "no memory files found", "expected": [str(x) for x in DEFAULT_MEM_FILES]}
    return "```json\n" + json.dumps(merged, ensure_ascii=False, indent=2) + "\n```"

def _compose_content() -> str:
    return f"**NEURO-LITE MEMORY**\n{MARKER}\n{_load_memory_json()}"

async def _keeper_update(bot: commands.Bot, th: discord.Thread, content: str) -> Optional[discord.Message]:
    # Try message_keeper if available, else fallback to send
    try:
        from satpambot.bot.modules.discord_bot.helpers.message_keeper import get_keeper
        keeper = get_keeper(bot)
        msg = await keeper.update(th, key=KEEPER_KEY, content=content)
        return msg
    except Exception as e:
        log.warning("[memory_pinner] keeper unavailable -> %s", e)
        if not ALLOW_SEND_FALLBACK:
            return None
        try:
            msg = await th.send(content)
            with contextlib.suppress(Exception):
                await msg.pin(reason="Neuro-Lite memory keeper (fallback)")
            return msg
        except Exception as e2:
            log.warning("[memory_pinner] fallback send failed: %s", e2)
            return None

async def _find_memory_messages(th: discord.Thread) -> Tuple[Optional[discord.Message], list]:
    """Return (primary_msg, duplicates) based on MARKER/keeper signature among pins + recent history."""
    primary = None
    dups: list = []
    # Pinned first
    with contextlib.suppress(Exception):
        pins = await th.pins()
        for m in pins:
            if m.author and getattr(m.author, "bot", False) and isinstance(m.content, str) and ("NEURO-LITE MEMORY" in m.content or "[neuro-lite:" in m.content or "<!-- [neuro-lite:memory] -->" in m.content):
                if primary is None:
                    primary = m
                else:
                    dups.append(m)
    # Recent history (to catch unpinned keeper)
    try:
        async for m in th.history(limit=50):
            if m.author and getattr(m.author, "bot", False) and isinstance(m.content, str) and ("NEURO-LITE MEMORY" in m.content or "[neuro-lite:" in m.content or "<!-- [neuro-lite:memory] -->" in m.content):
                if primary is None:
                    primary = m
                elif m.id != getattr(primary, "id", 0) and all(m.id != x.id for x in dups):
                    dups.append(m)
    except Exception:
        pass
    return primary, dups

class NeuroLiteMemoryPinner(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._last_blob = None
        self.ensure_once.start()
        self.watch_task.start()

    def cog_unload(self):
        for t in (self.ensure_once, self.watch_task):
            try: t.cancel()
            except Exception: pass

    async def _cleanup_dups(self, th: discord.Thread, keep_msg: Optional[discord.Message], dups: list):
        # prefer edit-in-place; duplicates: unpin, optionally delete (allowlisted)
        # import allowlist API lazily to avoid cycles
        try:
            from satpambot.bot.modules.discord_bot.cogs.delete_safe_shim import allow_delete_for
        except Exception:
            allow_delete_for = None
        for m in dups:
            with contextlib.suppress(Exception):
                if m.pinned:
                    await m.unpin(reason="cleanup duplicate neuro-lite memory")
            if CLEANUP_DELETE and allow_delete_for:
                try:
                    allow_delete_for(int(m.id))
                    await m.delete()
                except Exception:
                    pass

    async def _upsert_and_pin(self) -> Optional[discord.Message]:
        th = await ensure_neuro_thread(self.bot, DEFAULT_THREAD_NAME)
        if not th:
            log.warning("[memory_pinner] cannot ensure neuro thread")
            return None

        blob = _compose_content()
        # try find existing
        msg, dups = await _find_memory_messages(th)
        if msg is None:
            # create/update via keeper or fallback
            msg = await _keeper_update(self.bot, th, blob)
        else:
            # edit in place
            try:
                await msg.edit(content=blob)
            except Exception:
                # if edit fails (permissions?), send new
                msg = await _keeper_update(self.bot, th, blob)
        # pin ensure
        if msg:
            with contextlib.suppress(Exception):
                await msg.pin(reason="Neuro-Lite memory keeper")
            # cleanup duplicates
            await self._cleanup_dups(th, msg, dups)
            self._last_blob = blob
            log.info("[memory_pinner] memory keeper upserted & pinned in thread #%s", getattr(th, "name", "?"))
        return msg

    @tasks.loop(count=1)
    async def ensure_once(self):
        await self.bot.wait_until_ready()
        await asyncio.sleep(1.0)
        await self._upsert_and_pin()

    @tasks.loop(minutes=10)
    async def watch_task(self):
        await self.bot.wait_until_ready()
        try:
            blob = _compose_content()
            if blob != self._last_blob:
                await self._upsert_and_pin()
        except Exception:
            log.exception("[memory_pinner] watch loop error")

    @ensure_once.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    @watch_task.before_loop
    async def _before_watch(self):
        await self.bot.wait_until_ready()

async def setup(bot: commands.Bot):
    await bot.add_cog(NeuroLiteMemoryPinner(bot))
