# modules/editor/__init__.py

from .routes import editor_bp
