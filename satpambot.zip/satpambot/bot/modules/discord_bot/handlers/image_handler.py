async def handle_image_message(message, bot):
    # (optional) placeholder for image-specific checks
    return
