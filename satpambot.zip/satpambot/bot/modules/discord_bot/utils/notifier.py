def format_log_message(user, reason: str) -> str:
    return f"{user} — {reason}"
