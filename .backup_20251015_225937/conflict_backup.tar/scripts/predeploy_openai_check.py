# scripts/predeploy_vendor_check.py (renamed concept)
print("Vendor predeploy check deprecated. Using Groq stack.")  # neutralized
