# minimal stub: OK if importable
print('smoke_online stub: OK')
