print("Deprecated utility. Use GROQ/LLM configs.")
