StickyDoctor v2 — run --fix or --fix --hard. See scripts/smoke_sticky_healthz.py to verify.
