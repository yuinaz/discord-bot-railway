# scripts/apply_hotfixes.py
print("Hotfix runner: no vendor-specific actions required.")  # neutralized
