print("This script is deprecated. Use GROQ model settings instead.")
